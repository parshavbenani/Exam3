﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.Models
{
    public enum Globle
    {
        Pending,
        Approve,
        Reject,
        Block
        
    }
    public enum RoleType
    {
        SuperAdmin,
        Admin,
        Dealer,
        User
    }
}
